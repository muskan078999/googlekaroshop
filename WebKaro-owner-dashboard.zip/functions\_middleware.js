import { verifyOwner } from '../lib/access.js';

function jsonResponse(body, status) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    }
  });
}

export async function onRequest(context) {
  const { pathname } = new URL(context.request.url);
  const ownerRoute = pathname === '/owner' || pathname.startsWith('/owner/');
  const adminApi = pathname === '/api/admin' || pathname.startsWith('/api/admin/');

  if (ownerRoute || adminApi) {
    const result = await verifyOwner(context.request, context.env);
    if (!result.ok) return jsonResponse({ error: result.error }, result.status);
  }

  return context.next();
}
