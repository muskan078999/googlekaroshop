const MAX_BODY_BYTES = 16_000;
const MAX_AGE_DAYS = 90;

function jsonResponse(body, status) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    }
  });
}

function validText(value, maxLength, required = false) {
  return typeof value === 'string' && value.length <= maxLength && (!required || value.trim().length > 0);
}

async function readLimitedBody(request) {
  if (!request.body) return '';
  const reader = request.body.getReader();
  const chunks = [];
  let byteLength = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    byteLength += value.byteLength;
    if (byteLength > MAX_BODY_BYTES) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }

  const body = new Uint8Array(byteLength);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return new TextDecoder().decode(body);
}

export async function onRequestPost({ request, env }) {
  if (!env.LEADS_DB) return jsonResponse({ error: 'Enquiry storage is not configured.' }, 503);

  const origin = request.headers.get('origin');
  if (origin) {
    try {
      if (new URL(origin).origin !== new URL(request.url).origin) {
        return jsonResponse({ error: 'This enquiry could not be accepted.' }, 403);
      }
    } catch {
      return jsonResponse({ error: 'This enquiry could not be accepted.' }, 403);
    }
  }

  const contentLength = Number(request.headers.get('content-length') || 0);
  if (contentLength > MAX_BODY_BYTES) return jsonResponse({ error: 'The enquiry is too large.' }, 413);

  let rawBody;
  try {
    rawBody = await readLimitedBody(request);
  } catch (error) {
    console.error('Could not read a WebKaro enquiry request body.', error);
    return jsonResponse({ error: 'The enquiry could not be read.' }, 400);
  }
  if (rawBody === null) {
    return jsonResponse({ error: 'The enquiry is too large.' }, 413);
  }

  let lead;
  try {
    lead = JSON.parse(rawBody);
  } catch {
    return jsonResponse({ error: 'The enquiry data is invalid.' }, 400);
  }

  if (
    !lead ||
    !validText(lead.need, 80, true) ||
    !validText(lead.biz, 80, true) ||
    !validText(lead.budget, 40, true) ||
    !validText(lead.goal, 100, true) ||
    !validText(lead.name, 80, true) ||
    !validText(lead.business, 100, true) ||
    !validText(lead.phone, 24, true) ||
    !validText(lead.email || '', 120) ||
    !validText(lead.city || '', 80) ||
    !validText(lead.desc || '', 1000) ||
    lead.consent !== true ||
    !/^\+?[\d\s()-]{8,24}$/.test(lead.phone.trim()) ||
    (lead.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email.trim()))
  ) {
    return jsonResponse({ error: 'Please check the required fields and consent, then try again.' }, 400);
  }

  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + MAX_AGE_DAYS * 24 * 60 * 60 * 1000);
  const values = [
    crypto.randomUUID(),
    createdAt.toISOString(),
    expiresAt.toISOString(),
    lead.need.trim(),
    lead.biz.trim(),
    lead.budget.trim(),
    lead.goal.trim(),
    lead.name.trim(),
    lead.business.trim(),
    lead.phone.trim(),
    (lead.email || '').trim(),
    (lead.city || '').trim(),
    (lead.desc || '').trim(),
    'New',
    createdAt.toISOString()
  ];

  try {
    await env.LEADS_DB.prepare(
      `INSERT INTO leads (
        id, created_at, expires_at, need, business_type, budget, goal,
        name, business, phone, email, city, description, status, consent_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(...values).run();
    await env.LEADS_DB.prepare('DELETE FROM leads WHERE expires_at <= ?')
      .bind(createdAt.toISOString())
      .run();
  } catch (error) {
    console.error('Could not save a WebKaro enquiry to D1.', error);
    return jsonResponse({ error: 'We could not save your enquiry just now. Please try WhatsApp instead.' }, 503);
  }

  return jsonResponse({ ok: true }, 201);
}

export async function onRequest(context) {
  if (context.request.method !== 'POST') {
    return new Response(null, { status: 405, headers: { allow: 'POST', 'cache-control': 'no-store' } });
  }
  return onRequestPost(context);
}
