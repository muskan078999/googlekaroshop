export default {
  async scheduled(event, env) {
    const cutoff = new Date().toISOString();
    await env.LEADS_DB.prepare('DELETE FROM leads WHERE expires_at <= ?').bind(cutoff).run();
  },

  async fetch() {
    return new Response('Not found', { status: 404 });
  }
};
