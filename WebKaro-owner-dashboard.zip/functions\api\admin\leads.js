function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    }
  });
}

export async function onRequestGet({ env }) {
  if (!env.LEADS_DB) return jsonResponse({ error: 'Enquiry storage is not configured.' }, 503);

  const now = new Date().toISOString();
  try {
    await env.LEADS_DB.prepare('DELETE FROM leads WHERE expires_at <= ?').bind(now).run();
    const { results } = await env.LEADS_DB.prepare(
      `SELECT id, created_at, need, business_type, budget, goal, name, business,
        phone, email, city, description, status, consent_at
       FROM leads
       WHERE expires_at > ?
       ORDER BY created_at DESC`
    ).bind(now).all();
    return jsonResponse({ leads: results });
  } catch (error) {
    console.error('Could not load WebKaro enquiries from D1.', error);
    return jsonResponse({ error: 'Enquiries could not be loaded.' }, 503);
  }
}

export async function onRequestDelete({ request, env }) {
  if (!env.LEADS_DB) return jsonResponse({ error: 'Enquiry storage is not configured.' }, 503);
  const id = new URL(request.url).searchParams.get('id') || '';
  if (!/^[0-9a-f-]{36}$/i.test(id)) return jsonResponse({ error: 'A valid enquiry ID is required.' }, 400);

  try {
    const result = await env.LEADS_DB.prepare('DELETE FROM leads WHERE id = ?').bind(id).run();
    if (!result.meta.changes) return jsonResponse({ error: 'That enquiry was not found.' }, 404);
    return jsonResponse({ ok: true });
  } catch (error) {
    console.error('Could not delete a WebKaro enquiry from D1.', error);
    return jsonResponse({ error: 'The enquiry could not be deleted.' }, 503);
  }
}

export async function onRequest({ request, env, next }) {
  if (request.method === 'GET') return onRequestGet({ env });
  if (request.method === 'DELETE') return onRequestDelete({ request, env });
  return new Response(null, { status: 405, headers: { allow: 'GET, DELETE', 'cache-control': 'no-store' } });
}
