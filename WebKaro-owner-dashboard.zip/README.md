# WebKaro.shop owner enquiries

This project is based on the latest `files.zip` downloaded from Claude. It keeps the submitted website and adds:

- A server-side Cloudflare Pages Function that validates and stores form submissions in Cloudflare D1.
- A private `/owner/` enquiries dashboard. Cloudflare Access email one-time PIN is the sign-in provider; the dashboard does not use a client-side password.
- Server-side Access JWT signature, audience, issuer, expiry and exact-owner-email checks before serving the dashboard or its data API.
- Enquiry deletion from the owner dashboard and automatic expiry after 90 days. A daily scheduled Worker physically removes expired D1 records; API requests also clean up expired records.
- Explicit form consent before submitting personal contact information.
- A Pages route allowlist keeps Functions limited to `/api/*` and `/owner*`; the public brochure remains static.

The existing published `webkaro-shop.pages.dev` site is unchanged until the updated project is deployed.

## Important: custom domain needed for Cloudflare Access

Cloudflare Access self-hosted public applications require an active domain/zone in the Cloudflare account. The current `pages.dev` address alone is not enough to configure the protected owner login. Buy/connect the WebKaro domain to the Pages project first. Until Access, D1 and the Functions are configured and redeployed, `/owner/` does not provide a working dashboard and the current live site still does not save enquiries.

Never publish the D1 database ID as a secret, but do not expose owner data or Access tokens. Do not place passwords or API tokens in website files.

## Deploy requirements

Install Node.js LTS, then open PowerShell in this project directory. Wrangler is run with `npx`; it is not a build dependency of the website.

1. Sign in to Cloudflare:

   ```powershell
   npx wrangler login
   ```

2. Create the D1 database and note the database ID returned:

   ```powershell
   npx wrangler d1 create webkaro-leads
   ```

3. Replace `REPLACE_WITH_D1_DATABASE_ID` with that ID in **both** `wrangler.toml` and `cleanup-worker/wrangler.toml`.

4. Create the table:

   ```powershell
   npx wrangler d1 execute webkaro-leads --remote --file=migrations/0001_create_leads.sql
   ```

5. Connect the purchased domain to the Pages project `webkaro-shop`. Then configure Cloudflare Access:

   - Enable **One-time PIN** as a login method in Cloudflare Zero Trust.
   - Create a self-hosted Access application for `your-domain/owner*`.
   - Create another self-hosted Access application for `your-domain/api/admin/*`. The public form endpoint `/api/submit` must remain outside Access.
   - For both applications, create an **Allow** policy matching only the owner's Cloudflare account email. Keep the default deny behavior for everyone else.
   - Record the Access team domain and both application audience tags.

6. In the Pages project’s **Settings → Variables and Secrets**, set these production variables:

   - `OWNER_EMAIL`: the exact owner email allowed by the two Access policies.
   - `ACCESS_TEAM_DOMAIN`: the Zero Trust team hostname, for example `team-name.cloudflareaccess.com` (hostname only).
   - `ACCESS_AUD`: the two application audience tags, separated by a comma.

   Do not make the owner-email Access policy broader than this single account. Configure variables for production, not untrusted preview deployments.

7. Deploy the Pages assets **and Functions** from this project directory:

   ```powershell
   npx wrangler pages deploy public --project-name webkaro-shop
   ```

   The Cloudflare dashboard's static Direct Upload does not deploy Pages Functions; Wrangler or Git integration is required for the form/API and protected dashboard code.

   In **Pages project → Settings → Runtime**, set **Fail open / closed** to **Fail closed** so authentication is never bypassed if the Functions quota is exhausted.

8. Deploy the daily 90-day retention cleanup:

   ```powershell
   npx wrangler deploy --config cleanup-worker/wrangler.toml
   ```

   This scheduled Worker has no public `workers.dev` hostname. Its only job is purging expired leads from the same D1 database once per day.

## Verify after deployment

- Submit a valid website enquiry and check that the form confirms it was received.
- Open `/owner/`; Cloudflare Access should request an email PIN, and only the configured owner email should be allowed.
- Confirm the enquiry appears on the dashboard and can be deleted.
- Verify an unauthenticated request to `/api/admin/leads` returns 401/403 and never returns lead data.
- Verify the request form still works without Access protecting `/api/submit`.

Enquiry names, phone numbers, email addresses and business details are personal data. Restrict access, use the data only for the enquiry, and follow applicable privacy/retention requirements. The form's 90-day retention does not replace a privacy notice or legal review.

## Project layout

- `public/`: static website, owner dashboard and Pages headers.
- `functions/`: Pages API, owner Access verification middleware and D1 operations.
- `lib/`: shared Access JWT verification helper (bundled by Pages Functions, not published as a static asset).
- `migrations/`: D1 table schema.
- `cleanup-worker/`: scheduled expiry cleanup.
- `wrangler.toml`: Pages project output and D1 binding.
